"""Export a quantized LayoutLMv3 token-classification model to ONNX.

Steps performed:
1. Download LayoutLMv3 processor and a token-classification head.
2. Export the model to ONNX (FP32) with dynamic axes.
3. Apply dynamic quantization with ONNX Runtime to significantly reduce file size.
"""

from __future__ import annotations

import argparse
import tempfile
from pathlib import Path
from typing import List

import torch
from PIL import Image
from transformers import LayoutLMv3ForTokenClassification, LayoutLMv3Processor
from onnxruntime.quantization import QuantType, quantize_dynamic

MODEL_ID = "microsoft/layoutlmv3-base"
DEFAULT_MODEL_DIR = "layoutlmv3_token_classifier"
DEFAULT_PROCESSOR_DIR = "layoutlmv3_processor"
DEFAULT_ONNX_NAME = "layoutlmv3_token_classifier_quant.onnx"
LABELS: List[str] = ["O", "B-ENT"]


class LayoutLMv3TokenClassifier(torch.nn.Module):
    """Wrapper to simplify ONNX export."""

    def __init__(self, model: LayoutLMv3ForTokenClassification) -> None:
        super().__init__()
        self.model = model

    def forward(
        self,
        input_ids: torch.Tensor,
        bbox: torch.Tensor,
        pixel_values: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> torch.Tensor:
        outputs = self.model(
            input_ids=input_ids,
            bbox=bbox,
            pixel_values=pixel_values,
            attention_mask=attention_mask,
        )
        return outputs.logits


def build_dummy_batch(processor: LayoutLMv3Processor) -> dict[str, torch.Tensor]:
    image = Image.new("RGB", (1024, 1024), color="white")
    words = ["This", "is", "a", "sample", "document", "for", "ONNX", "export"]
    step = 1000 // len(words)
    boxes = []
    for idx in range(len(words)):
        left = idx * step
        right = min(1000, left + step)
        boxes.append([left, 0, right, 200])

    encoded = processor(
        image,
        text=words,
        boxes=boxes,
        return_tensors="pt",
        truncation=True,
        padding="max_length",
    )

    keep_keys = {"input_ids", "bbox", "pixel_values", "attention_mask"}
    encoded = {k: v for k, v in encoded.items() if k in keep_keys}
    encoded["bbox"] = encoded["bbox"].to(dtype=torch.long)
    return encoded


def export(model_dir: Path, processor_dir: Path, onnx_path: Path, opset: int = 17) -> None:
    processor = LayoutLMv3Processor.from_pretrained(MODEL_ID, apply_ocr=False)
    processor.save_pretrained(processor_dir)

    id2label = {i: label for i, label in enumerate(LABELS)}
    label2id = {label: i for i, label in enumerate(LABELS)}
    model = LayoutLMv3ForTokenClassification.from_pretrained(
        MODEL_ID,
        num_labels=len(LABELS),
        id2label=id2label,
        label2id=label2id,
        ignore_mismatched_sizes=True,
    )
    model.save_pretrained(model_dir)
    model.eval()

    dummy_inputs = build_dummy_batch(processor)
    wrapper = LayoutLMv3TokenClassifier(model)

    dynamic_axes = {
        "input_ids": {0: "batch", 1: "sequence"},
        "bbox": {0: "batch", 1: "sequence"},
        "pixel_values": {0: "batch"},
        "attention_mask": {0: "batch", 1: "sequence"},
        "logits": {0: "batch", 1: "sequence"},
    }

    with tempfile.NamedTemporaryFile(suffix=".onnx", delete=False) as tmp_fp:
        tmp_fp_path = Path(tmp_fp.name)

    torch.onnx.export(
        wrapper,
        args=(
            dummy_inputs["input_ids"],
            dummy_inputs["bbox"],
            dummy_inputs["pixel_values"],
            dummy_inputs["attention_mask"],
        ),
        f=str(tmp_fp_path),
        input_names=["input_ids", "bbox", "pixel_values", "attention_mask"],
        output_names=["logits"],
        dynamic_axes=dynamic_axes,
        opset_version=opset,
        do_constant_folding=True,
    )

    quantize_dynamic(
        model_input=str(tmp_fp_path),
        model_output=str(onnx_path),
        weight_type=QuantType.QInt8,
    )

    tmp_fp_path.unlink(missing_ok=True)

    print(f"Saved processor to {processor_dir}")
    print(f"Saved PyTorch weights to {model_dir}")
    print(f"Exported quantized ONNX model to {onnx_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-dir", type=Path, default=Path(DEFAULT_MODEL_DIR))
    parser.add_argument("--processor-dir", type=Path, default=Path(DEFAULT_PROCESSOR_DIR))
    parser.add_argument("--onnx", type=Path, default=Path(DEFAULT_ONNX_NAME))
    parser.add_argument("--opset", type=int, default=17)
    args = parser.parse_args()

    args.model_dir.mkdir(parents=True, exist_ok=True)
    args.processor_dir.mkdir(parents=True, exist_ok=True)

    export(args.model_dir, args.processor_dir, args.onnx, opset=args.opset)


def check_dependencies() -> None:
    try:
        import onnxruntime  # noqa: F401
    except ImportError as exc:
        raise SystemExit(
            "onnxruntime is required for quantization. Install it with `pip install onnxruntime`"
        ) from exc


if __name__ == "__main__":
    check_dependencies()
    main()
